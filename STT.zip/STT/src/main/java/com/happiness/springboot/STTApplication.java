package com.happiness.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class STTApplication {

	public static void main(String[] args) {
		SpringApplication.run(STTApplication.class, args);
	}

}

